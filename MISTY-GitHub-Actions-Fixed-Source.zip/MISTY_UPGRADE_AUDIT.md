# MISTY Android project — implementation audit

## Project facts

- Existing project preserved; this is not a from-scratch replacement.
- Kotlin, Jetpack Compose, Android Gradle Plugin 8.7.3, Kotlin 2.0.21.
- Namespace/application ID: `app.shilex.android`.
- `minSdk 29`, `targetSdk 35`, Java 17.
- Existing AI connection: Gemini Live WebSocket, configured with a user-provided Gemini API key.
- Existing offline speech: Vosk (`vosk-model-small-en-in-0.4`, fetched at build time and SHA-256 checked).
- Existing wake-word path: ONNX Runtime / openWakeWord integration.
- Existing audio processing: SpeexDSP echo cancellation plus Android audio effects where available.
- Existing Android integrations: contacts, calendar, notifications, reminders, media intents, Accessibility Service and floating overlay.
- Existing local memory and user confirmation flows are present.

## Changes made in this upgrade pass

1. Added `MistyAvatar.kt`, a Compose avatar component that uses the user's supplied photograph as the visual reference.
2. Cropped and packaged the supplied photograph as `app/src/main/res/drawable-nodpi/misty_avatar.jpg`.
3. Integrated the avatar into the central HUD on the home screen. It has low-cost idle drift and state-driven scale/tint changes for listening and speaking.
4. Updated the README project heading and opening description to MISTY.
5. Added this audit so unsupported capabilities are not represented as completed.

## Existing functionality verified by source inspection

- MISTY is already the Android app label and `Branding.ASSISTANT_NAME`.
- The home screen already has idle/listening/processing/executing/speaking/error-style visual states, an animated HUD and a voice waveform.
- The app has an API-key vault, a Gemini Live client, Vosk local speech, local command routing, voice-profile enrollment, and an Android foreground microphone service.
- The project includes tool modules for app launch, contacts, calendar, messages, calls via app handoff, media controls, device status, reminders and screen interaction.
- Sensitive actions are designed around explicit user confirmation and Android permission gates.

## Important gaps — not claimed as implemented

### Voice identity and wake word

`VoiceProfile` currently compares normalized wake-model feature windows using cosine similarity. That is not a robust, dedicated speaker-embedding verifier and is not sufficient to promise that other speakers, replayed audio or synthetic voices will always be rejected. No dedicated anti-spoofing model is integrated. Do not use this as the sole authorization factor for sensitive actions.

The wake phrase is currently hard-coded as "Hey Jarvis" in the app's wake/local routing. The README and `app/src/debug/assets/wake/README.md` explain that the wake model is not included in the normal app assets because the available model is non-commercially licensed. A customizable "Hey MISTY" wake-word model is not included. Background wake listening therefore depends on an appropriately licensed model being supplied.

### AI model routing and web research

The current live AI implementation is Gemini-specific. There is no provider-neutral model router or automatic model selection across multiple providers. The current system prompt tells the assistant to open a web search for recent information; that is not an autonomous multi-source research engine, and it does not provide a verified source-comparison pipeline.

### Avatar animation

The new avatar is a portrait with subtle Compose motion. It is not a Live2D/3D rig and does not perform phoneme-level lip synchronization or detailed facial-expression animation. Those require a rigged character asset and audio-to-viseme/timing integration.

### Android phone control

Phone control is bounded by Android APIs, installed apps, runtime permissions, Accessibility opt-in and user confirmation. Some operations open an app with prepared content for the user to confirm rather than silently sending/calling. Direct control of arbitrary incoming/active call states is not guaranteed by the current project.

## Build and test status

A build/test attempt was made with:

```bash
./gradlew :app:testDebugUnitTest :app:assembleDebug --no-daemon
```

It stopped before Gradle could configure the project because the environment could not resolve `services.gradle.org` (`UnknownHostException`). The wrapper distribution could not be downloaded. Consequently, no compilation, unit-test or APK success is claimed for this pass.

## Build requirements

- JDK 17
- Android SDK Platform 35
- Android NDK `27.0.12077973`
- CMake `3.22.1`
- Internet access for Gradle dependencies and the pinned Vosk model download

From the project root, run:

```bash
./gradlew :app:testDebugUnitTest
./gradlew :app:assembleDebug
```

Debug APK output, if the build succeeds: `app/build/outputs/apk/debug/app-debug.apk`.

## User setup and privacy notes

- The existing app requires the user's own Gemini API key; configure it through the app's existing key setup screen.
- Microphone, contacts, calendar, notifications, overlay and Accessibility capabilities are permission-gated. Enable only the capabilities the user wants.
- The existing wake-word model limitation must be resolved with a model whose license permits the intended distribution.
- Keep the original GPL-3.0-or-later license and third-party notices when redistributing modified source.
