package app.shilex.android.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import app.shilex.android.Branding
import app.shilex.android.assistant.Line
import app.shilex.android.assistant.Phase
import app.shilex.android.assistant.UiState
import app.shilex.android.learn.HabitKeys
import app.shilex.android.local.ActivityLog
import app.shilex.android.local.LocalCommand
import app.shilex.android.local.LocalPhase
import app.shilex.android.local.MediaKey
import app.shilex.android.task.Task
import app.shilex.android.wake.WakeWordModel

/** What the assistant is doing, in words and a colour, from the session and the local turn. */
private data class Status(val title: String, val hint: String, val badge: String, val orb: Phase, val live: Boolean)

private fun status(state: UiState, local: LocalPhase, wakeOn: Boolean): Status = when {
    local == LocalPhase.Listening -> Status("Listening", "Say a command. Simple ones run on this phone.", "On phone", Phase.Listening, true)
    local == LocalPhase.Doing -> Status("Working", "Doing it on this phone.", "On phone", Phase.Connecting, true)
    local == LocalPhase.Speaking -> Status("Speaking", "Answered on this phone.", "On phone", Phase.Speaking, true)
    state.phase == Phase.Connecting -> Status("Thinking", "Connecting…", "Online", Phase.Connecting, true)
    state.phase == Phase.Listening -> Status("Listening", "Talk any time, in English, Hindi or Hinglish.", "Online", Phase.Listening, true)
    state.phase == Phase.Speaking -> Status("Speaking", "Tap the core to cut in.", "Online", Phase.Speaking, true)
    else -> Status(
        "Standby",
        state.problem ?: if (wakeOn) "Say \"${WakeWordModel.PHRASE}\", or tap the mic." else "Tap the mic to talk.",
        if (wakeOn) "Wake word on" else "Wake word off",
        Phase.Off,
        false,
    )
}

@Composable
fun HomeScreen(
    state: UiState,
    localPhase: LocalPhase,
    level: Float,
    task: Task?,
    activity: List<ActivityLog.Entry>,
    wakeOn: Boolean,
    onStart: () -> Unit,
    onStop: () -> Unit,
    onInterrupt: () -> Unit,
    onMicDenied: () -> Unit,
    onPermissionAnswered: (Boolean) -> Unit,
    onQuick: (LocalCommand) -> String,
    onSeeActivity: () -> Unit,
    favourites: List<LocalCommand> = emptyList(),
) {
    val context = LocalContext.current
    val askMic = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) onStart() else onMicDenied()
    }
    // A tool needs Contacts or notifications: show Android's own Allow dialog.
    val askForTool = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission(), onPermissionAnswered)
    LaunchedEffect(state.permissionNeeded) {
        state.permissionNeeded?.let(askForTool::launch)
    }
    val startListening = {
        val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (granted) onStart() else askMic.launch(Manifest.permission.RECORD_AUDIO)
    }
    val now = status(state, localPhase, wakeOn)
    val problem = state.problem != null && !now.live
    val hud = when {
        problem -> MistyState.Error
        localPhase == LocalPhase.Doing -> MistyState.Executing
        else -> when (now.orb) {
            Phase.Off -> MistyState.Idle
            Phase.Connecting -> MistyState.Processing
            Phase.Listening -> MistyState.Listening
            Phase.Speaking -> MistyState.Speaking
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("MISTY", style = MaterialTheme.typography.titleLarge.copy(letterSpacing = 5.sp, color = Color(0xFF42D9FF)))
                Text("YOUR PERSONAL AI ASSISTANT", style = MaterialTheme.typography.labelSmall, color = Muted, letterSpacing = 1.2.sp)
            }
            HudBadge(if (now.live) "● ${now.title.uppercase()}" else "● SYSTEM READY", if (problem) Warning else Color(0xFF38E6B1))
        }

        // Main holographic avatar stage, designed for a portrait Android display.
        Box(Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 10.dp), contentAlignment = Alignment.Center) {
            MistyHud(
                state = hud,
                level = level,
                modifier = Modifier.size(310.dp).semantics { contentDescription = "MISTY ${now.title}" }
                    .clickable(remember { MutableInteractionSource() }, indication = null) {
                        when (state.phase) {
                            Phase.Off -> if (localPhase == LocalPhase.Idle) startListening()
                            Phase.Speaking -> onInterrupt()
                            else -> Unit
                        }
                    },
            )
            MistyPortrait(
                speaking = hud == MistyState.Speaking,
                listening = hud == MistyState.Listening,
                modifier = Modifier.width(210.dp).height(264.dp),
            )
        }

        HudPanel(title = "MISTY ASSISTANT") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    AnimatedContent(now.title, label = "mistyStatus") { title ->
                        Text(title.uppercase(), style = MaterialTheme.typography.titleMedium, color = Color(0xFF65DFFF))
                    }
                    Text(
                        if (now.live) "I'm here. Tell me what you need." else "Hello! I'm MISTY. How can I help you today?",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color(0xFFE1F3FF),
                        modifier = Modifier.padding(top = 3.dp),
                    )
                    Text(now.hint, style = MaterialTheme.typography.bodySmall, color = if (problem) Warning else Muted, modifier = Modifier.padding(top = 4.dp))
                }
                MistyWave(hud, level, Modifier.width(86.dp).height(42.dp))
            }
        }

        Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
            HudPanel("VOICE SECURITY", Modifier.weight(1f)) {
                Text(if (wakeOn) "● Wake word enabled" else "● Tap to speak", color = Color(0xFF48E4B5), style = MaterialTheme.typography.bodySmall)
                Text("Microphone permission managed by Android", color = Muted, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(top = 4.dp))
            }
            HudPanel("DEVICE STATUS", Modifier.weight(1f)) {
                Text("● ${if (state.hasKey) "AI connected" else "Setup required"}", color = if (state.hasKey) Color(0xFF48E4B5) else Warning, style = MaterialTheme.typography.bodySmall)
                Text("Local actions available", color = Muted, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(top = 4.dp))
            }
        }

        HudPanel("QUICK ACTIONS", Modifier.padding(top = 10.dp)) {
            QuickActions(onQuick, favourites)
        }

        val recentTask = task?.takeIf { now.live || System.currentTimeMillis() - it.at < TASK_SHOWN_MS }
        recentTask?.let { TaskCard(it, Modifier.padding(top = 10.dp)) }
        if (state.phase != Phase.Off && state.lines.isNotEmpty()) {
            Conversation(state.lines, Modifier.fillMaxWidth().height(220.dp).padding(top = 10.dp))
        } else {
            HudPanel("RECENT ACTIVITY", Modifier.padding(top = 10.dp)) { Recent(activity.take(2), onSeeActivity) }
        }

        Row(Modifier.fillMaxWidth().padding(top = 14.dp, bottom = 20.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
            Text("SETTINGS", color = Muted, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(end = 18.dp))
            Text("MEMORY", color = Muted, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(end = 18.dp))
            FilledIconButton(
                onClick = { if (now.live) onStop() else startListening() },
                modifier = Modifier.size(76.dp),
                colors = if (now.live) IconButtonDefaults.filledIconButtonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant, contentColor = MaterialTheme.colorScheme.onSurface) else IconButtonDefaults.filledIconButtonColors(containerColor = Color(0xFF087FAE), contentColor = Color.White),
            ) { Icon(if (now.live) Icons.Filled.Close else MicIcon, contentDescription = if (now.live) "Stop listening" else "Start listening", modifier = Modifier.size(32.dp)) }
            Text("RESEARCH", color = Muted, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(start = 18.dp))
        }
    }
}

@Composable
private fun HudPanel(title: String, modifier: Modifier = Modifier, content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit) {
    Column(
        modifier.fillMaxWidth()
            .background(Color(0xB3091B2D), RoundedCornerShape(16.dp))
            .border(1.dp, Color(0x7732CFFF), RoundedCornerShape(16.dp))
            .padding(12.dp),
    ) {
        Text(title, color = Color(0xFF54DFFF), style = MaterialTheme.typography.labelMedium, letterSpacing = 1.1.sp)
        Spacer(Modifier.height(7.dp))
        content()
    }
}

@Composable
private fun HudBadge(text: String, tint: Color) {
    Text(text, color = tint, style = MaterialTheme.typography.labelSmall,
        modifier = Modifier.background(Color(0xAA071827), RoundedCornerShape(50)).border(1.dp, tint.copy(alpha = .55f), RoundedCornerShape(50)).padding(horizontal = 10.dp, vertical = 7.dp))
}

/** One-tap phone actions; they run here, with no network. */
@Composable
private fun QuickActions(onQuick: (LocalCommand) -> String, favourites: List<LocalCommand>) {
    var torchOn by remember { mutableStateOf(false) }
    var answer by remember { mutableStateOf<String?>(null) }
    // Learned favourites first, topped up with the defaults.
    val learned = favourites.mapNotNull { command -> HabitKeys.key(command)?.let { HabitKeys.describe(it).replaceFirstChar(Char::uppercase) to { command } } }
    val defaults = listOf(
        (if (torchOn) "Torch off" else "Torch") to {
            torchOn = !torchOn
            LocalCommand.Torch(torchOn)
        },
        "Battery" to { LocalCommand.Battery },
        "Time" to { LocalCommand.Time },
        "Pause" to { LocalCommand.Media(MediaKey.Pause) },
    )
    val actions = (learned + defaults.filter { d -> learned.none { it.first.startsWith(d.first, ignoreCase = true) } }).take(4)
    Column {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            actions.forEach { (label, command) ->
                Box(
                    Modifier
                        .weight(1f)
                        .background(Surface, MaterialTheme.shapes.small)
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, MaterialTheme.shapes.small)
                        .clickable { answer = onQuick(command()) }
                        .padding(vertical = 14.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(label, style = MaterialTheme.typography.labelLarge, maxLines = 1)
                }
            }
        }
        answer?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = Muted, modifier = Modifier.padding(top = 8.dp, start = 4.dp)) }
    }
}

@Composable
private fun Recent(entries: List<ActivityLog.Entry>, onSeeAll: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text("RECENT", style = MaterialTheme.typography.titleSmall, color = Muted, modifier = Modifier.weight(1f).padding(start = 4.dp))
        TextButton(onClick = onSeeAll) { Text("See all") }
    }
    if (entries.isEmpty()) {
        Text("Nothing yet. What you ask shows up here.", style = MaterialTheme.typography.bodySmall, color = Muted, modifier = Modifier.padding(start = 4.dp))
    }
    entries.forEach { ActivityRow(it) }
}

@Composable
private fun Conversation(lines: List<Line>, modifier: Modifier) {
    val list = rememberLazyListState()
    LaunchedEffect(lines.size, lines.lastOrNull()?.text) {
        if (lines.isNotEmpty()) list.animateScrollToItem(lines.lastIndex)
    }
    LazyColumn(modifier, state = list, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(lines, key = { it.id }) { line ->
            Box(Modifier.fillMaxWidth(), contentAlignment = if (line.fromUser) Alignment.CenterEnd else Alignment.CenterStart) {
                Text(
                    line.text,
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (line.fromUser) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier
                        .background(if (line.fromUser) Accent else Surface, RoundedCornerShape(16.dp))
                        .padding(horizontal = 14.dp, vertical = 9.dp),
                )
            }
        }
    }
}

private const val TASK_SHOWN_MS = 2 * 60_000L
